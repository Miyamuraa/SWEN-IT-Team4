<?php
/*Copyright (C) 2006 Tony Iha Kazungu
Hotel Management Information System (HotelMIS Version 1.0), is an interactive system that enables small to medium
sized hotels take guests bookings and make hotel reservations.  It could either be uploaded to the internet or used
on the hotel desk computers.  It keep tracks of guest bills and posting of receipts.  Hotel reports can alos be
produce to make work of the accounts department easier.

This program is free software; you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program;
if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA or 
check for license.txt at the root folder

For any details please feel free to contact me at taifa@users.sourceforge.net
Or for snail mail. P. O. Box 938, Kilifi-80108, East Africa-Kenya.
*/
session_start();
error_reporting(E_ALL & ~E_NOTICE);
include_once("login_check.inc.php");
include_once ("queryfunctions.php");
include_once ("functions.php");
access("admin"); //check if user is allowed to access this page
$conn=db_connect(HOST,USER,PASS,DB,PORT);

if (isset($_GET["search"])){
	find($_GET["search"]);
}	

if (isset($_POST['Submit'])){
	$action=$_POST['Submit'];
	switch ($action) {
		case 'Add User': //|| 'Update User'):
			// instantiate form validator object
			$fv=new formValidator(); //from functions.php
			$fv->validateEmpty('fname','Enter users First name');
			$fv->validateEmpty('lname','Enter users Last name');
			$fv->validateEmpty('loginname','Enter users Login name');
			$fv->validateEmpty('nric','Please enter an NRIC');
			$fv->validateEmpty('address','Please enter an Address');
			$fv->validateEmpty('bank_acct_no','Please enter Bank Account Number');
			$fv->validateEmpty('pass','Please enter a password');
						
			if($fv->checkErrors()){
				// display errors
				echo "<div align=\"center\">";
				echo '<h2>Resubmit the form after correcting the following errors:</h2>';
				echo $fv->displayErrors();
				echo "</div>";
			}else {
				$fname=$_POST["fname"];
				$lname=$_POST["lname"];
				$loginname=$_POST["loginname"];
				$pass=$_POST["pass"];
				$nric=$_POST["nric"];
				$mobile=(!empty($_POST["mobile"])) ? $_POST["mobile"] : 'NULL';
				$address=$_POST["address"];
                $dob=(!empty($_POST["dob"])) ? $_POST["dob"] : 'NULL';
                $bank_acct_no=$_POST["bank_acct_no"];			
				$email=(!empty($_POST["email"])) ? $_POST["email"] : 'NULL';
				$admin=(empty($_POST["admin"])) ? 0 : $_POST["admin"];
				$guest=(empty($_POST["guest"])) ? 0 : $_POST["guest"];
				$reservation=(empty($_POST["reservation"])) ? 0 : $_POST["reservation"];
				$booking=(empty($_POST["booking"])) ? 0 : $_POST["booking"];
				$agents=(empty($_POST["agents"])) ? 0 : $_POST["agents"];
				$rooms=(empty($_POST["rooms"])) ? 0 : $_POST["rooms"];
				$billing=(empty($_POST["billing"])) ? 0 : $_POST["billing"];
				$rates=(empty($_POST["rates"])) ? 0 : $_POST["rates"];
				$lookup=(empty($_POST["lookup"])) ? 0 : $_POST["lookup"];
				$reports=(empty($_POST["reports"])) ? 0 : $_POST["reports"];
				
				//check if it's an update or a new insert
				/*if ($action=='Update User'){
					echo "Put sql statement for updating here";
					//echo different $msg0 & 1
				}else{ //adding*/
					$sql="INSERT INTO users (fname,lname,loginname,pass,nric,mobile,address,email,dob,bank_acct_no,dateregistered,admin,guest,reservation,booking,agents,rooms,billing,rates,lookup,reports)
	 					VALUES('$fname','$lname','$loginname','$pass','$nric',$mobile,'$address','$email','$dob',$bank_acct_no,now(),$admin,$guest,$reservation,$booking,$agents,$rooms,$billing,$rates,$lookup,$reports)";
				//}
				
				$results=mkr_query($sql,$conn);
				$msg[0]="Sorry user account no created";
				$msg[1]="User account created successful";
				AddSuccess($results,$conn,$msg);	
			}
			break;
		case 'Update User':
			echo "Put sql statement for updating here";		
			break;
		case 'List':
			//link ("self","agents_list.php");
			break;
		case 'Find':
			//check if user is searching using name, payrollno, national id number or other fields
			$search=$_POST["search"];
			find($search);
			break;
	}

}

function find($search){
	global $conn,$users;
	$search=$search;
	$sql="select fname,lname,loginname,nric,mobile,address,email,bank_acct_no,pass,admin,
		guest,reservation,booking,agents,rooms,billing,rates,lookup,reports
		From users where userid='$search'";
	$results=mkr_query($sql,$conn);
	$users=fetch_object($results);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/new.css" rel="stylesheet" type="text/css">
<title>Hotel Management System</title>

<script type="text/javascript">
<!--
var request;
var dest;

function loadHTML(URL, destination){
    dest = destination;
	if (window.XMLHttpRequest){
        request = new XMLHttpRequest();
        request.onreadystatechange = processStateChange;
        request.open("GET", URL, true);
        request.send(null);
    } else if (window.ActiveXObject) {
        request = new ActiveXObject("Microsoft.XMLHTTP");
        if (request) {
            request.onreadystatechange = processStateChange;
            request.open("GET", URL, true);
            request.send();
        }
    }
}

function processStateChange(){
    if (request.readyState == 4){
        contentDiv = document.getElementById(dest);
        if (request.status == 200){
            response = request.responseText;
            contentDiv.innerHTML = response;
        } else {
            contentDiv.innerHTML = "Error: Status "+request.status;
        }
    }
}

function loadHTMLPost(URL, destination){
    dest = destination;
	if (window.XMLHttpRequest){
        request = new XMLHttpRequest();
        request.onreadystatechange = processStateChange;
        request.open("POST", URL, true);
        request.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
		request.send("str");
    } else if (window.ActiveXObject) {
        request = new ActiveXObject("Microsoft.XMLHTTP");
        if (request) {
            request.onreadystatechange = processStateChange;
            request.open("POST", URL, true);
            request.send();
        }
    }
}
//-->	 
</script>
</head>

<body>
<form action="admin.php" method="post" enctype="multipart/form-data">
<table width="20%"  border="0" cellpadding="1" bgcolor="#66CCCC" align="left">
  <tr valign="top">
    <td width="18%" valign="top" bgcolor="#FFFFFF">
	<table width="100%" border="0" cellpadding="1" cellspacing="5">
	  <tr>
    <td bgcolor="#66CCCC" valign="top">
		<table cellspacing=0 cellpadding=0 width="100%" align="left" bgcolor="#FFFFFF">
      <tr><td align="center"><img src="images/logo.png" width="100" height="200" border="0"/></td></tr>
      <tr>
        <td align="center">
		<?php signon(); ?>		
		</td></tr>
	  </table></td></tr>
<table align="center" cellpadding="1">
		<?php require_once("menu_header.php"); ?>
		</table>
    </table>
	</td>
    </table>
	
	
	
    <table width="80%"  border="1" cellpadding="5" cellspacing="5" align="right">
      <tr>
        <td><h2>Administrator</h2></td>
      </tr>
	<tr>
        <td><div id="Requests">
<table width="82%"  border="0" cellpadding="1">
  <tr>

    <td><input type="hidden" name="userid" readonly="" value="<?php echo trim($users->userid); ?>"/></td>

    <td><input type="hidden" name="dateregistered" readonly="" value="<?php echo trim($users->dateregistered); ?>" /></td>
  </tr>
  <tr>
    <td>Login Name</td>
    <td><input type="text" name="loginname" value="<?php echo trim($users->loginname); ?>"/></td>
	<td>Mobile</td>
    <td><input type="text" name="mobile" value="<?php echo trim($users->mobile); ?>"/></td>
  </tr>
  <tr>
    <td>First Name </td>
    <td><input type="text" name="fname" value="<?php echo trim($users->fname); ?>"/></td>
    <td>Address</td>
    <td><input type="text" name="address" value="<?php echo trim($users->address); ?>"/></td>
  </tr>
  <tr>

	<td>Last Name </td>
    <td><input type="text" name="lname" value="<?php echo trim($users->lname); ?>"/></td>

	<td>Email</td>
    <td><input type="text" name="email" value="<?php echo trim($users->email); ?>"/></td>
  </tr>
  <tr>
  	<td>Date Of Birth</td>
    <td><input type="date" name="dob" value="<?php echo trim($users->dob); ?>"/></td>
  	<td>Bank Account No.</td>
    <td><input type="text" name="bank_acct_no" value="<?php echo trim($users->bank_acct_no); ?>"/></td>
  </tr>
  <tr>
    <td>NRIC</td>
    <td><input type="text" name="nric" value="<?php echo trim($users->nric); ?>"/></td>  
	<td>Password</td>
    <td><input type="password]" name="pass" value="<?php echo trim($users->pass); ?>"/></td>
  </tr>
  

</table>
  <section>
  <h3>Access Rights</h3>

    <table cellpadding="10">
	  <tr>
      <td>Administrator
      <input type="checkbox" name="admin" value="1" <?php if($users->admin==1) echo "checked";?>/></td>
	  <td>guest
      <input type="checkbox" name="guest" value="1" <?php if($users->guest==1) echo "checked";?>/></td>
	  <td>reservation
      <input type="checkbox" name="reservation" value="1" <?php if($users->reservation==1) echo "checked";?>/></td>
	  <td>booking
      <input type="checkbox" name="booking" value="1" <?php if($users->booking==1) echo "checked";?>/></td>
	  <td>agents
      <input type="checkbox" name="agents" value="1" <?php if($users->agents==1) echo "checked";?>/></td>
  </tr>

      <tr>
        <td>rooms
        <input type="checkbox" name="rooms" value="1" <?php if($users->rooms==1) echo "checked";?>/></td>
		<td>billing
        <input type="checkbox" name="billing" value="1" <?php if($users->billing==1) echo "checked";?>/></td>
		<td>rates
        <input type="checkbox" name="rates" value="1" <?php if($users->rates==1) echo "checked";?>/></td>
		<td>lookup
        <input type="checkbox" name="lookup" value="1" <?php if($users->lookup==1) echo "checked";?>/></td>
		<td>reports
        <input type="checkbox" name="reports" value="1" <?php if($users->reports==1) echo "checked";?>/></td>
      </tr>
	  
	  <tr>
	    <td><input type="submit" name="Submit" value="<?php echo isset($_GET["search"]) ? "Update User" : "Add User" ?>"/></td>
		<td><input type="button" name="Submit" value="Staff List" onclick="self.location='users_list.php'"/></td>
		</tr>
		
    </table>

</section>

</table>
</form>
</body>
</html>