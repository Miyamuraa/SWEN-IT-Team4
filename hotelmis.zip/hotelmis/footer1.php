<!--/*****************************************************************************
/*Copyright (C) 2006 Tony Iha Kazungu
/*****************************************************************************
Hotel Management Information System (HotelMIS Version 1.0), is an interactive system that enables small to medium
sized hotels take guests bookings and make hotel reservations.  It could either be uploaded to the internet or used
on the hotel desk computers.  It keep tracks of guest bills and posting of receipts.  Hotel reports can alos be
produce to make work of the accounts department easier.

This program is free software; you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program;
if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA or 
check for license.txt at the root folder
/*****************************************************************************
For any details please feel free to contact me at taifa@users.sourceforge.net
Or for snail mail. P. O. Box 938, Kilifi-80108, East Africa-Kenya.
/*****************************************************************************/-->
</tr>
  <td colspan="2">
  <table>
  <tr><td><a href="http://www.php.net" target="_blank"><img src="images/php-power-white.gif" width="88" height="31" border="0" /></a></td>
  <td><a href="http://www.mysql.com" target="_blank"><img src="images/powered-by-mysql-88x31.png" width="88" height="31" border="0" /></a></td>
  <td>TaifaTech Networks &copy; 2006. Vers 1.0</td>
  <td><a href="http://sourceforge.net"><img src="http://sflogo.sourceforge.net/sflogo.php?group_id=172638&amp;type=1" width="88" height="31" border="0" alt="SourceForge.net Logo" /></a></td>
  </table>
  </td>
  </tr>